/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.WorkQueue;

import Food.Order;
import business.Enterprise.Enterprise;
import business.Enterprise.Restaurant;

/**
 *
 * @author liuch
 */
public class OrphaneRequest {
   Order order;
    Enterprise receiver;
    public OrphaneRequest(Enterprise e)
    {
        super();
        order = new Order();
        receiver = e;
        
    }
}
